M1 IMIS
Quentin Cognard - 2163498

Projet Petit Grand

Travail r�alis� :

- Les nombreuses formes ont �t� r�alis� avec leur couleur correspondante + des formes supl�mentaires.

- Le jeu est fonctionnel

- Le gamePlay a �t� modif� avec des nouveaut�s :
	 - un nouveau concept pr�vu sp�cialement pour un seul joueur 15 cartes au lieu de 30
	 - un systeme de Joker visant � rendre le jeu plus simple ( essayez de l'utiliser en appuyant sur sa t�te vous verez ^^ )
	 - le jeu est gagn� lorsque le joueur a vid� sa pile
	 - si le paris est perdu les cartes sont remises sous la pile � d�couvrir ( il faut donc jouer de sa m�moire et des probabilit�s )

- L'interface a �t� repens�e :
	- une jauge permettant de voir le nombre de cartes restantes
	- des symboles clair
	- le nouveau symbole Joker ( vous verez, il se modifie meme quand on l'utilise... )
	- un �cran de victoire fort sympatique
	- l'icone repr�sentant le charismatique Joker

- Petite feature bonus : on peut s'amuser � bouger les formes qui repr�sentent les animaux pr�sent dans le jeu ( appuyer et bouger )